package com.cg.dao;

import java.util.List;

import com.cg.beans.Employee;



public interface EmployeeDao {
	public List<Employee> getAllRecords();

}
