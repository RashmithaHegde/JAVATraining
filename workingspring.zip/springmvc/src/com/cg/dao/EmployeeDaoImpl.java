package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import com.cg.beans.Employee;
import com.cg.utils.DbUtils;


public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public List<Employee> getAllRecords() {
		List<Employee> list=new ArrayList<Employee>();
		try{
			Connection con=DbUtils.getConnection();
			PreparedStatement ps=con.prepareStatement("SELECT * FROM EMPLOYEE ORDER BY EMPID");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Employee emp =new Employee();
				emp.setEmpId(rs.getInt("empId"));
				emp.setEmpName(rs.getString("empName"));
				emp.setEmpPlace(rs.getString("empPlace"));
			
				list.add(emp);
			}
		}catch(Exception e){System.out.println(e);}
		return list;
	}
	
	

}
