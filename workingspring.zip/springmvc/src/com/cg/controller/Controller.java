package com.cg.controller;

import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.dao.EmployeeDao;
import com.cg.dao.EmployeeDaoImpl;


public class Controller {
	
	public void getSummary()
	{
		EmployeeDaoImpl dao=new EmployeeDaoImpl();
		dao.getAllRecords();
	}
	

}
