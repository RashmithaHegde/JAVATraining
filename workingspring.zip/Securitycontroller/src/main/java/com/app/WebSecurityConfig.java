package com.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

@EnableWebSecurity  
@ComponentScan("com.app")  
public class WebSecurityConfig {

	  @Bean  
	    public UserDetailsService userDetailsService() throws Exception {  
	        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();  
	        manager.createUser(User.withDefaultPasswordEncoder().username("javatpoint").  
	        password("javatpoint123").roles("ADMIN").build());  
	        return manager;  
	    }  
	      
	  
	    protected void configure(HttpSecurity http) throws Exception {  
	    	http  
	    	.authorizeRequests()  
	    	.anyRequest().authenticated()  
	    	.and()  
	    	.formLogin()  
	    	.and()  
	    	.httpBasic();  
	    	}  
}
