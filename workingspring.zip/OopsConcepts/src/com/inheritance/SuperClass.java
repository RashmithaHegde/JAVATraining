package com.inheritance;

public class SuperClass {
 
static int salary=100000;
public static void printName() {
	System.out.println("your salary is:"+salary);
}
}
