package com.inheritance;

public class SubClass extends SuperClass{
	int price=500;
	public static void main(String[] args) {
		printName();
		System.out.println(salary);
	}

}
