package com.encapsulation;

public class EncapsulationMain {

	public static void main(String[] args) {
		EncapsulationExample encapsulationExample = new EncapsulationExample("Hello World");
		
		String name;
		name = encapsulationExample.toString();
		System.out.println(name);

	}

}
