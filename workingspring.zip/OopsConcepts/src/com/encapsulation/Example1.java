package com.encapsulation;

import java.util.Scanner;

public class Example1 {
	static int n;
	static int a=1;
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of n");
		int n=sc.nextInt();
		if(n==a) {
			System.out.println("hi please help us wth coding god");
		}
		else {
			System.out.println("or else you only type n execute ");
		}
		sc.close();
	}

}
