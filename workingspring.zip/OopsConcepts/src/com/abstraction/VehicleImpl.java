package com.abstraction;

public class VehicleImpl implements Vehicle 
{

	@Override
	public  void car() 
	{
		System.out.println("This is a car method");
		
	}
	
	public static void main(String[] args) 
	{
		VehicleImpl vehicle = new VehicleImpl();
		vehicle.car();
	}

}
