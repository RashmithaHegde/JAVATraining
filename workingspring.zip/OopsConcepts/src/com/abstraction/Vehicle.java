package com.abstraction;

public interface Vehicle {
	public void car();

}
