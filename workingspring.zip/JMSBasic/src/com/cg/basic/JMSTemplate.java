package com.cg.basic;

public class JMSTemplate {

	public static void main(String[] args) {
		Producer.main(null);
		Consumer.main(null);

	}

}
