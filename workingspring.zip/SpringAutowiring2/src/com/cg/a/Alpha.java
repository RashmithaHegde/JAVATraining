package com.cg.a;

public class Alpha {
	Alpha()
{
		System.out.println("constructor alpha is called");
}
void reuslt() {
	System.out.println("Print alpha");
}
}
