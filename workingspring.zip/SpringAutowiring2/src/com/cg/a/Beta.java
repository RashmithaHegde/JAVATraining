package com.cg.a;

import org.springframework.beans.factory.annotation.Autowired;

public class Beta {
	@Autowired
	Alpha alph;

	public Beta() {
		System.out.println("constructor beta is called");
	}

	public Alpha getAlph() {
		return alph;
	}

	
	public void setAlph(Alpha alph) {
		this.alph = alph;
	}
	void result() {
		System.out.println("output part of beta");
	}

	void display() {
		result();
	    alph.reuslt();
	}
}
